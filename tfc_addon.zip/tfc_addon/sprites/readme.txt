Extract into your halflife/tfc/sprites directory.
I made this hud for use with sparkies. It looks better using sparkies with a white hud color set, but it actually works without sparkies. (The white parts are just yellow instead).
Anyway, I wanted to give more of a TFC look to the current HUD sets coming out, so I made new icons for armor, rockets, pipes, cells, shells, etc. Hope you like it.
AGT-SuperSumo